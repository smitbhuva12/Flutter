package com.example.gredient_btn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
