package com.example.launch_btn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
