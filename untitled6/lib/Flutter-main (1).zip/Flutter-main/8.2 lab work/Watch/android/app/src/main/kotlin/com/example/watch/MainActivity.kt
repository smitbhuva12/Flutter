package com.example.watch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
