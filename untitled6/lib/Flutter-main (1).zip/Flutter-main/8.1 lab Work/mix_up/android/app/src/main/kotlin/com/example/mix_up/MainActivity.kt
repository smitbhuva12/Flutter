package com.example.mix_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
