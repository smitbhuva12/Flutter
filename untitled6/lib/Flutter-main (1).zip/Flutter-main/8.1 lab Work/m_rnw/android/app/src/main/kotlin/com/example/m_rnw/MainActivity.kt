package com.example.m_rnw

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
